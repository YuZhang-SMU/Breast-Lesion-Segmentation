
%% Demo to show the results of MCG
clear all;close all;
file_path = './results/original/';
image_path_list = dir(strcat(file_path,'*.png'));
image_num = length(image_path_list);
% mkdir('./results/sp_high/');
if image_num>0
    coordinate = xlsread('./results/point_original.xls','Sheet1','B1:G10');
    
    for k=1:image_num
        j=k;
        image_name = image_path_list(j).name;
        image = imread(strcat(file_path,image_name));
        if (length(size(image))>2)
            image = rgb2gray(image);
        end
%         image=255-image;
        fprintf('正在处理%d %s\n',j,strcat(file_path,image_name));
        [candidates_mcg, ucm2_mcg] = im2mcg(image,'accurate');
        
        [m,n]=size(image);
        
        % Show Object Candidates results and bounding boxes
        mask_final = zeros(m,n);
        [p,q]=size(candidates_mcg.labels);
        for i = 1:p
            id = i;
            mask = ismember(candidates_mcg.superpixels, candidates_mcg.labels{id});
%             if mask(coordinate(j,1),coordinate(j,2)) == 1 || (mask(coordinate(j,3),coordinate(j,4)) == 1 || mask(coordinate(j,5),coordinate(j,6)) == 1 && mask(m,n) == 0)
            if mask(coordinate(j,1),coordinate(j,2)) == 1 || mask(coordinate(j,3),coordinate(j,4)) == 1 || mask(coordinate(j,5),coordinate(j,6)) == 1
                mask_final = mask_final + mask; 
            end
        end
        mask_final(:,:) = (mask_final(:,:) - min(min(mask_final)))/(max(max(mask_final)) - min(min(mask_final)))*255;
        mask_final = uint8(mask_final);
        imwrite(mask_final,['./results/sp_high/',image_name],'png')
    end
end
