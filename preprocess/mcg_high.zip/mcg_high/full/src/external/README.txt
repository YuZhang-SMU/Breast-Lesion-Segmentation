All the code provided in this folder come from external sources as described
in each header. They have been, however, slightly modified to correct some
compilation warning and errors on Linux, Mac, and Windows.
