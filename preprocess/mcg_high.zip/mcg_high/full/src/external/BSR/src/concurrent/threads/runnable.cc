/*
 * Runnable.
 */
#include "concurrent/threads/runnable.hh"

namespace concurrent {
namespace threads {

/*
 * Pure virtual destructor.
 */
runnable::~runnable() { }

} /* namespace threads */
} /* namespace concurrent */
