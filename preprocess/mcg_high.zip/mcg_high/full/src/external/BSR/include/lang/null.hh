/*
 * Define NULL.
 */
#ifndef LANG__NULL_HH
#define LANG__NULL_HH

#ifndef NULL
#define NULL 0
#endif

#endif
